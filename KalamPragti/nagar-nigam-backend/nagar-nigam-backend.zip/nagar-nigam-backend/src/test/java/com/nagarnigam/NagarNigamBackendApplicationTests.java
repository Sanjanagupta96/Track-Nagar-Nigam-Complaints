package com.nagarnigam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NagarNigamBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
