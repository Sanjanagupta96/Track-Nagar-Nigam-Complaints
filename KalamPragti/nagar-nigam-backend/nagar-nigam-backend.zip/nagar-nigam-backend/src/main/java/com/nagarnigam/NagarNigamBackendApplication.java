package com.nagarnigam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NagarNigamBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(NagarNigamBackendApplication.class, args);
	}

}
